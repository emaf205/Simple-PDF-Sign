# PDF Image Placer

Web app statica per inserire firme, timbri, loghi e altre immagini sopra un PDF.

## Uso
1. Apri `index.html` nel browser.
2. Trascina un PDF nell'area iniziale.
3. Premi **Inserisci immagine** e scegli una o più immagini.
4. Trascina l'immagine sopra la pagina.
5. Usa il quadratino in basso a destra per ridimensionare e il pallino superiore per ruotare.
6. Premi **Esporta PDF**.

Il credit nell'interfaccia è: **Made with ♥ in Milan by Emanuele BDC**, con link mail a `emagumroad@gmail.com`. Non viene inserito nei PDF esportati.

## Privacy
Il contenuto del PDF e delle immagini viene elaborato nel browser e non viene inviato dall'app a un server. Questa versione carica PDF.js e pdf-lib da CDN, quindi serve una connessione Internet per caricare le librerie JavaScript.
