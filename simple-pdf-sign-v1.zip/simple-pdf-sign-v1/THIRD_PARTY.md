# Third-party libraries

This project uses the following client-side libraries:

- PDF.js — Mozilla, Apache License 2.0 — https://github.com/mozilla/pdf.js
- pdf-lib — Andrew Dillon / contributors, MIT License — https://github.com/Hopding/pdf-lib

The application code in this folder does not upload user PDFs or images to these projects or their CDNs.
