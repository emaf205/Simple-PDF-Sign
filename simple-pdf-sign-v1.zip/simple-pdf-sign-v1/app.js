/* global pdfjsLib, PDFLib */
(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const pdfInput = $('pdfInput');
  const imageInput = $('imageInput');
  const dropScreen = $('dropScreen');
  const dropZone = $('dropZone');
  const viewer = $('viewer');
  const pagesHost = $('pages');
  const insertLabel = $('insertLabel');
  const exportBtn = $('exportBtn');
  const newBtn = $('newBtn');
  const fileName = $('fileName');
  const toast = $('toast');

  pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

  const state = {
    pdfBytes: null,
    pdfProxy: null,
    fileName: '',
    pages: [],
    items: [],
    selectedId: null,
    seq: 1,
  };

  const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
  const normalizeAngle = (a) => ((a % 360) + 360) % 360;

  function notify(message, error = false) {
    toast.textContent = message;
    toast.className = `toast show${error ? ' error' : ''}`;
    clearTimeout(notify.timer);
    notify.timer = setTimeout(() => { toast.className = 'toast'; }, 2200);
  }

  function resetAll() {
    state.pdfBytes = null;
    state.pdfProxy = null;
    state.fileName = '';
    state.pages = [];
    state.items = [];
    state.selectedId = null;
    state.seq = 1;
    pagesHost.innerHTML = '';
    fileName.textContent = '';
    viewer.hidden = true;
    dropScreen.hidden = false;
    exportBtn.disabled = true;
    newBtn.hidden = true;
    insertLabel.classList.add('disabled');
    pdfInput.value = '';
    imageInput.value = '';
  }

  async function loadPdf(file) {
    if (!file || (!/pdf$/i.test(file.type) && !/\.pdf$/i.test(file.name))) {
      notify('Seleziona un file PDF valido.', true);
      return;
    }

    try {
      const bytes = await file.arrayBuffer();
      const proxy = await pdfjsLib.getDocument({ data: bytes.slice(0) }).promise;
      state.pdfBytes = bytes;
      state.pdfProxy = proxy;
      state.fileName = file.name;
      state.items = [];
      state.selectedId = null;
      fileName.textContent = file.name;
      dropScreen.hidden = true;
      viewer.hidden = false;
      exportBtn.disabled = false;
      newBtn.hidden = false;
      insertLabel.classList.remove('disabled');
      await renderPages();
      notify(`PDF caricato: ${proxy.numPages} pagina${proxy.numPages === 1 ? '' : 'e'}.`);
    } catch (err) {
      console.error(err);
      notify('Impossibile aprire il PDF. Il file potrebbe essere danneggiato o protetto.', true);
    }
  }

  function targetCssWidth(baseWidth) {
    const available = Math.max(280, Math.min(960, window.innerWidth - 38));
    return Math.min(baseWidth * 1.32, available);
  }

  async function renderPages() {
    if (!state.pdfProxy) return;
    pagesHost.innerHTML = '';
    state.pages = [];
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    for (let i = 0; i < state.pdfProxy.numPages; i++) {
      const page = await state.pdfProxy.getPage(i + 1);
      const base = page.getViewport({ scale: 1 });
      const cssWidth = targetCssWidth(base.width);
      const cssScale = cssWidth / base.width;
      const cssViewport = page.getViewport({ scale: cssScale });
      const renderViewport = page.getViewport({ scale: cssScale * dpr });

      const wrap = document.createElement('div');
      wrap.className = 'page-wrap';
      wrap.dataset.page = String(i);
      wrap.style.width = `${cssViewport.width}px`;
      wrap.style.height = `${cssViewport.height}px`;

      const canvas = document.createElement('canvas');
      canvas.width = Math.ceil(renderViewport.width);
      canvas.height = Math.ceil(renderViewport.height);
      canvas.style.width = `${cssViewport.width}px`;
      canvas.style.height = `${cssViewport.height}px`;

      const overlay = document.createElement('div');
      overlay.className = 'overlay';
      overlay.dataset.page = String(i);

      const number = document.createElement('div');
      number.className = 'page-number';
      number.textContent = `Pagina ${i + 1}`;

      wrap.append(canvas, overlay, number);
      pagesHost.appendChild(wrap);

      state.pages.push({
        page,
        wrap,
        canvas,
        overlay,
        rotation: normalizeAngle(page.rotate || 0),
      });

      const ctx = canvas.getContext('2d', { alpha: false });
      await page.render({ canvasContext: ctx, viewport: renderViewport }).promise;
    }
    renderItems();
  }

  function mostVisiblePageIndex() {
    if (!state.pages.length) return 0;
    const top = 62;
    const bottom = window.innerHeight;
    let best = 0;
    let bestVisible = -1;
    state.pages.forEach((p, i) => {
      const r = p.wrap.getBoundingClientRect();
      const visible = Math.max(0, Math.min(r.bottom, bottom) - Math.max(r.top, top));
      if (visible > bestVisible) { bestVisible = visible; best = i; }
    });
    return best;
  }

  async function imageFileToPng(file) {
    if (!file || !file.type.startsWith('image/')) throw new Error('not-image');
    const dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(file);
    });
    const img = await new Promise((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = reject;
      el.src = dataUrl;
    });
    const maxSide = 4096;
    const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.max(1, Math.round(img.naturalWidth * scale));
    const h = Math.max(1, Math.round(img.naturalHeight * scale));
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, w, h);
    return { dataUrl: canvas.toDataURL('image/png'), aspect: w / h };
  }

  async function addImages(files) {
    if (!state.pdfProxy) return;
    const list = [...files].filter(f => f.type.startsWith('image/'));
    if (!list.length) { notify('Seleziona almeno un’immagine valida.', true); return; }
    const pageIndex = mostVisiblePageIndex();
    let offset = 0;

    for (const file of list) {
      try {
        const { dataUrl, aspect } = await imageFileToPng(file);
        const p = state.pages[pageIndex];
        const pageAspect = p.wrap.clientWidth / p.wrap.clientHeight;
        let w = 0.27;
        let h = (w * pageAspect) / aspect;
        if (h > 0.28) { h = 0.28; w = (h * aspect) / pageAspect; }
        const item = {
          id: `img-${state.seq++}`,
          name: file.name || 'Immagine',
          pageIndex,
          dataUrl,
          x: clamp(0.5 - w / 2 + offset, 0, 1 - w),
          y: clamp(0.5 - h / 2 + offset, 0, 1 - h),
          w, h,
          rotation: 0,
        };
        state.items.push(item);
        state.selectedId = item.id;
        offset += 0.025;
      } catch (err) {
        console.error(err);
        notify(`Non riesco a leggere ${file.name}.`, true);
      }
    }
    renderItems();
    imageInput.value = '';
  }

  function selectItem(id) {
    state.selectedId = id;
    renderItems();
  }

  function removeItem(id) {
    state.items = state.items.filter(x => x.id !== id);
    if (state.selectedId === id) state.selectedId = null;
    renderItems();
  }

  function renderItems() {
    state.pages.forEach(p => p.overlay.innerHTML = '');
    for (const item of state.items) {
      const p = state.pages[item.pageIndex];
      if (!p) continue;
      const el = document.createElement('div');
      el.className = `placed${item.id === state.selectedId ? ' selected' : ''}`;
      el.dataset.id = item.id;
      el.style.left = `${item.x * 100}%`;
      el.style.top = `${item.y * 100}%`;
      el.style.width = `${item.w * 100}%`;
      el.style.height = `${item.h * 100}%`;
      el.style.transform = `rotate(${item.rotation}deg)`;
      el.innerHTML = `
        <img draggable="false" src="${item.dataUrl}" alt="">
        <span class="rotate-line"></span>
        <span class="handle resize" title="Ridimensiona"></span>
        <span class="handle rotate" title="Ruota"></span>
        <button class="delete" type="button" title="Elimina">×</button>`;
      p.overlay.appendChild(el);
      bindPlaced(el, item, p);
    }
  }

  function bindPlaced(el, item, page) {
    el.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.resize') || e.target.closest('.rotate') || e.target.closest('.delete')) return;
      e.preventDefault(); e.stopPropagation();
      state.selectedId = item.id;
      el.classList.add('selected');
      const startX = e.clientX, startY = e.clientY;
      const start = { x: item.x, y: item.y };
      el.setPointerCapture?.(e.pointerId);

      const move = (ev) => {
        const r = page.wrap.getBoundingClientRect();
        item.x = clamp(start.x + (ev.clientX - startX) / r.width, 0, 1 - item.w);
        item.y = clamp(start.y + (ev.clientY - startY) / r.height, 0, 1 - item.h);
        el.style.left = `${item.x * 100}%`;
        el.style.top = `${item.y * 100}%`;
      };
      const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up, { once: true });
    });

    el.querySelector('.resize').addEventListener('pointerdown', (e) => {
      e.preventDefault(); e.stopPropagation();
      state.selectedId = item.id; el.classList.add('selected');
      const startX = e.clientX, startY = e.clientY;
      const startW = item.w, startH = item.h;
      const aspectNorm = startW / startH;
      const move = (ev) => {
        const r = page.wrap.getBoundingClientRect();
        const dw = (ev.clientX - startX) / r.width;
        const dh = (ev.clientY - startY) / r.height;
        const candidateW = Math.max(0.025, startW + dw);
        const candidateH = Math.max(0.025, startH + dh);
        if (Math.abs(dw) >= Math.abs(dh)) {
          item.w = Math.min(candidateW, 1 - item.x);
          item.h = Math.min(item.w / aspectNorm, 1 - item.y);
        } else {
          item.h = Math.min(candidateH, 1 - item.y);
          item.w = Math.min(item.h * aspectNorm, 1 - item.x);
        }
        el.style.width = `${item.w * 100}%`;
        el.style.height = `${item.h * 100}%`;
      };
      const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up, { once: true });
    });

    el.querySelector('.rotate').addEventListener('pointerdown', (e) => {
      e.preventDefault(); e.stopPropagation();
      state.selectedId = item.id; el.classList.add('selected');
      const move = (ev) => {
        const r = el.getBoundingClientRect();
        const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
        item.rotation = Math.atan2(ev.clientY - cy, ev.clientX - cx) * 180 / Math.PI + 90;
        el.style.transform = `rotate(${item.rotation}deg)`;
      };
      const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up, { once: true });
    });

    el.querySelector('.delete').addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); removeItem(item.id); });
    el.addEventListener('click', (e) => { e.stopPropagation(); selectItem(item.id); });
  }

  function dataUrlToBytes(dataUrl) {
    const b64 = dataUrl.split(',')[1];
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  function inverseRotatedPoint(xd, yd, W, H, rotation) {
    switch (normalizeAngle(rotation)) {
      case 90: return { x: W - yd, y: xd };
      case 180: return { x: W - xd, y: H - yd };
      case 270: return { x: yd, y: H - xd };
      default: return { x: xd, y: yd };
    }
  }

  async function exportPdf() {
    if (!state.pdfBytes) return;
    exportBtn.disabled = true;
    exportBtn.textContent = 'Esporto…';
    try {
      const pdfDoc = await PDFLib.PDFDocument.load(state.pdfBytes.slice(0));
      const pages = pdfDoc.getPages();
      const imageCache = new Map();

      for (const item of state.items) {
        const page = pages[item.pageIndex];
        if (!page) continue;
        const W = page.getWidth(), H = page.getHeight();
        const rotation = normalizeAngle(page.getRotation().angle || 0);
        const dW = rotation === 90 || rotation === 270 ? H : W;
        const dH = rotation === 90 || rotation === 270 ? W : H;

        let embedded = imageCache.get(item.dataUrl);
        if (!embedded) {
          embedded = await pdfDoc.embedPng(dataUrlToBytes(item.dataUrl));
          imageCache.set(item.dataUrl, embedded);
        }

        const w = item.w * dW;
        const h = item.h * dH;
        const cxD = (item.x + item.w / 2) * dW;
        const cyD = (1 - item.y - item.h / 2) * dH;
        const c = inverseRotatedPoint(cxD, cyD, W, H, rotation);

        // PDF rotation is counter-clockwise; CSS rotation is clockwise on the displayed page.
        const thetaDeg = rotation - item.rotation;
        const theta = thetaDeg * Math.PI / 180;
        const x = c.x - Math.cos(theta) * w / 2 + Math.sin(theta) * h / 2;
        const y = c.y - Math.sin(theta) * w / 2 - Math.cos(theta) * h / 2;

        page.drawImage(embedded, {
          x, y, width: w, height: h,
          rotate: PDFLib.degrees(thetaDeg),
        });
      }

      const out = await pdfDoc.save();
      const blob = new Blob([out], { type: 'application/pdf' });
      const a = document.createElement('a');
      const stem = state.fileName.replace(/\.pdf$/i, '') || 'documento';
      a.href = URL.createObjectURL(blob);
      a.download = `${stem}-modificato.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 3000);
      notify('PDF esportato.');
    } catch (err) {
      console.error(err);
      notify('Errore durante l’esportazione del PDF.', true);
    } finally {
      exportBtn.disabled = false;
      exportBtn.textContent = 'Esporta PDF';
    }
  }

  pdfInput.addEventListener('change', () => loadPdf(pdfInput.files[0]));
  imageInput.addEventListener('change', () => addImages(imageInput.files));
  exportBtn.addEventListener('click', exportPdf);
  newBtn.addEventListener('click', resetAll);

  dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('dragover'); });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault(); dropZone.classList.remove('dragover');
    const file = [...e.dataTransfer.files].find(f => f.type === 'application/pdf' || /\.pdf$/i.test(f.name));
    if (file) loadPdf(file); else notify('Trascina un file PDF valido.', true);
  });

  pagesHost.addEventListener('click', (e) => {
    if (!e.target.closest('.placed')) { state.selectedId = null; renderItems(); }
  });

  window.addEventListener('keydown', (e) => {
    if ((e.key === 'Delete' || e.key === 'Backspace') && state.selectedId) {
      e.preventDefault(); removeItem(state.selectedId);
    }
  });

  let resizeTimer;
  window.addEventListener('resize', () => {
    if (!state.pdfProxy) return;
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(renderPages, 180);
  });
})();
